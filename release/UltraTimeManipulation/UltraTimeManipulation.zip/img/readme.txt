You are able to change the HUD here if you wish, but make sure to use PNGs AND retain the file name.
Changing the dimensions of the HUD elements may result in undesired effects.
underlayTop.png is rendered over underlay.png. underlay.png is not shown for the "minimal HUD".